import rclpy 
import numpy as np
from rclpy.node import Node 
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class random_walk(Node):
    move = 'str'
    min_angle = 0
    min_scan = 0
    timer_cnt=0

    def __init__(self):
        # wake up node name
        super().__init__("random_walk")
        self.subscription = self.create_subscription(LaserScan, "/scan", self.get_scan_values, 10)
        self.publisher = self.create_publisher(Twist, "/my_robot/cmd_vel", 10)
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.send_cmd_vel)
        self.velocity = Twist()
        self.linear_x = 0.3
        self.linear_y = 0.0
        self.linear_z = 0.0
        self.angle_x = 0.0
        self.angle_y = 0.0
        self.angle_z = 0.0
        #self.subscription

    def get_scan_values(self, scan_data):
        ranges = scan_data.ranges
        ranges = np.array(ranges)
        length = len(ranges)
        inf = float('inf')
        ranges[ranges == inf] = 0.0
        ranges_args = ranges.nonzero()
        scan_value = ranges[ranges_args]
        #print("length={}, \nranges_args={}, \nscan_value={}".format(length, ranges_args, scan_value))

        #ランダムウォークのプログラム
        if len(ranges_args)>0:
            #最小の値をサーチ
            try:
                obs_value = np.argmin(scan_value)
                self.min_scan = scan_value[obs_value]
                self.min_angle = ranges_args[0][obs_value]
            except:
                return
            
            if self.min_scan<1.0:
                #print(type(ranges_args))
                #print(len(ranges_args))
                #最小の値の角度
                #obs_angle = ranges_args[0][self.min_scan]/2
                if self.min_angle < 90.0 and self.min_angle > 0.0:
                    self.move = 'left'
                elif self.min_angle > 90.0 and  self.min_angle < 180.0:
                    self.move = 'right'
            else:
                self.move = 'str'
        else:
            self.move = 'str'

    def send_cmd_vel(self):
        print(self.move, self.min_scan, self.min_angle)
        self.timer_cnt = self.timer_cnt+1
        if self.timer_cnt > 20:
            self.timer_cnt = 20
            if self.move == 'str':
                self.linear_x = 0.3
                self.angle_z = 0.0
            elif self.move == 'left':
                self.linear_x = 0.0
                self.angle_z = 0.5
                self.timer_cnt=0       
            elif self.move == 'right':
                self.linear_x = 0.0
                self.angle_z = -0.5
                self.timer_cnt=0
        # setting linear velocity
        self.velocity.linear.x = self.linear_x
        self.velocity.linear.y = self.linear_y
        self.velocity.linear.z = self.linear_z
        self.velocity.angular.x = self.angle_x
        self.velocity.angular.y = self.angle_y
        self.velocity.angular.z = self.angle_z
        self.publisher.publish(self.velocity)

def main(args=None):
    rclpy.init(args=args)
    gl = random_walk()
    rclpy.spin(gl)
    rclpy.shutdown()

if __name__ == "__main__":
    main()