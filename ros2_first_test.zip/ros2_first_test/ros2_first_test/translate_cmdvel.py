import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class cmdvel2Rover(Node):
    def __init__(self):
        # wake up node name
        super().__init__("Translate_cmdvel2_node")
        # declare publisher
        self.publisher = self.create_publisher(Twist, "/first_robot/cmd_vel", 40)
        # declare subscriber
        self.subscription = self.create_subscription(Twist, "/cmd_vel", self.get_scan_values, 40)
        # period publisher
        timer_period = 0.2
        self.timer = self.create_timer(timer_period, self.send_cmd_vel)
        # creating a message object to fit new velocities and publish them
        self.velocity = Twist()

        self.linear_x = 0.0
        self.linear_y = 0.0
        self.linear_z = 0.0
        self.angle_x = 0.0
        self.angle_y = 0.0
        self.angle_z = 0.0

    def get_scan_values(self, scan_data):
        # separate scan data
        self.linear_x = scan_data.linear.x
        self.linear_y = scan_data.linear.y
        self.linear_z = scan_data.linear.z
        self.angle_x = scan_data.angular.x
        self.angle_y = scan_data.angular.y
        self.angle_z = scan_data.angular.z

    def send_cmd_vel(self):
        # setting linear velocity
        self.velocity.linear.x = self.linear_x
        self.velocity.linear.y = self.linear_y
        self.velocity.linear.z = self.linear_z
        self.velocity.angular.x = -self.angle_x/2
        self.velocity.angular.y = -self.angle_y/2
        self.velocity.angular.z = -self.angle_z/2

        self.publisher.publish(self.velocity)


def main(args=None):
    rclpy.init(args=args)
    oab = cmdvel2Rover()
    rclpy.spin(oab)
    rclpy.shutdown()

if __name__ == "__main__":
    main()