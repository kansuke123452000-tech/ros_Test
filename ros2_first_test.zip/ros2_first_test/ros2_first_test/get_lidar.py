import rclpy 
from rclpy.node import Node 
from sensor_msgs.msg import LaserScan
import numpy as np

class getLidar(Node):
    def __init__(self):
        # wake up node name
        super().__init__("lidar_subscriber")
        self.subscription = self.create_subscription(LaserScan, "/scan", self.get_scan_values, 10)
        self.subscription

    def get_scan_values(self, scan_data):
        ranges = scan_data.ranges
        ranges = np.array(ranges)
        length = len(ranges)
        inf = float('inf')
        ranges[ranges == inf] = 0.0
        ranges_args = ranges.nonzero()
        scan_value = ranges[ranges_args]
        print("length={}, \nranges_args={}, \nscan_value={}".format(length, ranges_args, scan_value))

        #最近のオブジェクトをサーチ
        obs_value = np.argmin(scan_value)
        
        print(obs_value)
        print(ranges_args[0][obs_value])

def main(args=None):
    rclpy.init(args=args)
    gl = getLidar()
    rclpy.spin_once(gl)
    rclpy.shutdown()

if __name__ == "__main__":
    main()